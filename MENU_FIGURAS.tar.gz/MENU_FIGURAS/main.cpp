#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <math.h>


//DECLARACION DE VARIABLES A UTILIZAR

int id_menu[1]; // vector donde almacenaremos el id de la imagen a imprimir

float rx,ry;
float winHeight;
float winWind;
//obteniendo la posicion del raton al hacer click
void motion(int x, int y)
{
	rx=float(x);
	ry=winHeight - float (y);
}

//obtenindo la posicion del raton al hacer mover y presionar el click derecho
void mousebotton(int botton , int state, int x, int y)
{
	if(botton == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		rx= float(x);
		ry= winHeight - float (y);
		
		
		}
	
	}
void init (void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-10, 10, -10, 10, -10, 10);
}

void menu(int opc){
    id_menu[1]=opc;
    glClear (GL_COLOR_BUFFER_BIT); 	
    glPushMatrix();
    glTranslated((rx*0.001), (ry*0.001), 0.0);
    switch(opc){ 
       case 1:
       //glRotatef(40,0.1,0.1,0.0);
        glutWireSphere (0.2,8,8);
           break;

case 2:
       glutWireCube (0.18);
	
           break;
case 3:

		glutWireCone (0.1,0.2,6,6);
	
           break;
case 4:

glutWireTeapot (0.1);
		
           break;

case 5:
		glutWireTetrahedron ();
	
           break;


case 6:
		
		glutWireOctahedron ();
           break;           
case 7:

glutWireDodecahedron ();
        
           break;
case 8:
		
		glutWireIcosahedron ();
           break;
case 9:
		
	glutWireTorus (0.5,0.4,5,2);
           break;
         

                  
case 10:
		exit(0);
   }
   glutPostRedisplay();
   glFlush();
}

// METODO QUE RE DIBUJA LA PANTALLA
void redraw( void ){
    //Limpiando la pantalla
    glClear(GL_COLOR_BUFFER_BIT);
    // Haciendo uso del metodo menu, pasandoles como paramentro el id
    menu(id_menu[1]);
	glutSwapBuffers();
}

int main(int argc, char *argv[]){
	winWind = 600.0;
	winHeight = 400.0;
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
    glutCreateWindow("Figuras por mouse");
    glutPositionWindow(200,200);
    glutReshapeWindow(int (winWind) , int (winHeight));
    init ();
     
    glutCreateMenu(menu);
      glutAddMenuEntry("ESFERA",1);
      glutAddMenuEntry("CUBO",2);
      glutAddMenuEntry("CONO",3);
      glutAddMenuEntry("TETERA",4);
      glutAddMenuEntry("TETAHEDRO",5);
      glutAddMenuEntry("OCTAHEDRO",6);
      glutAddMenuEntry("DEDOCAHEDRO",7);
      glutAddMenuEntry("ICOSAHEDRO",8);
      glutAddMenuEntry("TORUS",9);
      
      
      glutAddMenuEntry("SALIR",10);

      glutAttachMenu(GLUT_RIGHT_BUTTON);
	  glMatrixMode(GL_PROJECTION);
      glLoadIdentity();
	  glutDisplayFunc(redraw);
	  glutIdleFunc(redraw);
	  glutMotionFunc(motion);
	  glutMouseFunc(mousebotton);
	 // mousebotton();
    glutMainLoop();
    return 0;
}
